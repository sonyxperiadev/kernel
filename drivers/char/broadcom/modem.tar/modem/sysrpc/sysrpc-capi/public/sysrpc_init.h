/******************************************************************************
*
* (c) 1999-2008 Broadcom Corporation
*
* Unless you and Broadcom execute a separate written software license agreement
* governing use of this software, this software is licensed to you under the
* terms of the GNU General Public License version 2, available at
* http://www.broadcom.com/licenses/GPLv2.php (the "GPL").
*
******************************************************************************/

#ifndef _SYSRPC_INIT_H
#define _SYSRPC_INIT_H

void SYS_InitRpc(void);

#endif /*_SYSRPC_INIT_H */
